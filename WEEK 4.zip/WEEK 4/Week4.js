var task1 = new Vue({
    el: '#task1',
    data: {
        message: 'Hello to the world of Vue!'


    }
})

var task2a = new Vue({
    el: '#task2a',
    data: {
        seen: true
    }
})

var task2b = new Vue({
    el: '#task2b',
    data: {
        show: true

    }
})

var task2d = new Vue({
    el: '#task2c',
    data: {
        todos: [
            { text: 'Ask for assistance with Proof of Concept' },
            { text: 'Do Week 4 tasks' },
            { text: 'Submit assignment 1' }
        ]
    }
})