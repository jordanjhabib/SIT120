// var x = 123;
// x.toString();

function myTask1() {
    var txt = "123abc456def789ghi";
    var txtLength = txt.length;
    document.getElementById("answer1").innerHTML = txtLength;
}

function myTask2() {
    var a = 78;
    var j = 4638;
    var answer = a + j - a * 2;
    document.getElementById("answer").innerHTML = answer;
}

function myTask2a() {
    var animals = ["Cat", " Dog", " Shark", " Monkey", " Sheep", " Bear", " Wolf", " Fox"];
    let text = "";
    for (let i = 0; i < animals.length; i++) {
        text += animals[i];
        document.getElementById("animals").innerHTML = animals;
    }
}

function myTask3() {
    var a = Date();
    document.getElementById("date").innerHTML = a;
}