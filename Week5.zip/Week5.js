new Vue({
    el: '#task3',
    data: {
        selected : ''
    }
})